import config from './config'

export function getuser () {
  console.log(config.user.getuser)
}
