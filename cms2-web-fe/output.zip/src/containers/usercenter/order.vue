<template lang="html">
  <div class="bg">
    <div class="row">
      <div class="col-xs-12">
        <div class="equip-con">
          <div class="picture-item">
            <img src="http://img254.oss-cn-beijing.aliyuncs.com/century/232/5ce/2325ce1cf7110f08076f8a19640b4fc7.jpg">
            <p>2017年马拉松 国际 参赛</p>
          </div>
          <div class="picture-item">
            <img src="http://img254.oss-cn-beijing.aliyuncs.com/century/232/5ce/2325ce1cf7110f08076f8a19640b4fc7.jpg">
            <p>2017年马拉松 国际 参赛</p>
          </div>
          <div class="picture-item">
            <img src="http://img254.oss-cn-beijing.aliyuncs.com/century/232/5ce/2325ce1cf7110f08076f8a19640b4fc7.jpg">
            <p>2017年马拉松 国际 参赛</p>
          </div>
          <div class="picture-item">
            <img src="http://img254.oss-cn-beijing.aliyuncs.com/century/232/5ce/2325ce1cf7110f08076f8a19640b4fc7.jpg">
            <p>2017年马拉松 国际 参赛</p>
          </div>
          <div class="picture-item">
            <img src="http://img254.oss-cn-beijing.aliyuncs.com/century/232/5ce/2325ce1cf7110f08076f8a19640b4fc7.jpg">
            <p>2017年马拉松 国际 参赛</p>
          </div>
          <div class="picture-item">
            <img src="http://img254.oss-cn-beijing.aliyuncs.com/century/232/5ce/2325ce1cf7110f08076f8a19640b4fc7.jpg">
            <p>2017年马拉松 国际 参赛</p>
          </div>
          <div class="picture-item">
            <img src="http://img254.oss-cn-beijing.aliyuncs.com/century/232/5ce/2325ce1cf7110f08076f8a19640b4fc7.jpg">
            <p>2017年马拉松 国际 参赛</p>
          </div>
          <div class="picture-item">
            <img src="http://img254.oss-cn-beijing.aliyuncs.com/century/232/5ce/2325ce1cf7110f08076f8a19640b4fc7.jpg">
            <p>2017年马拉松 国际 参赛</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'order',
  data () {
    return {
      password: '',
      password1: '',
      password2: '',
      error: ''
    }
  },
  methods: {
    pwdUser () {

    }
  }
}
</script>

<style scoped>
  .equip-con {
    padding: 20px 7px 0 20px;
    font-size: 0;
  }
</style>
