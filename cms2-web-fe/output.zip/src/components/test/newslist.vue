<template lang="html">
  <div class="newslist bgw">
    <h4 class="title_two">相关资讯 / Related info</h4>
    <ul>
      <li><span>2017-03-25</span><img src="/static/img/news.png" alt=""><a href="#">三天走出一个马拉松</a></li>
      <li><img src="/static/img/news.png" alt="">特跑族组委会向尚善公益特跑族组委会向尚善公益</li>
      <li><img src="/static/img/news.png" alt="">三天走出一个马拉松</li>
      <li><img src="/static/img/news.png" alt="">特跑族组委会向尚善公益特跑族组委会向尚善公益</li>
      <li><img src="/static/img/news.png" alt="">三天走出一个马拉松</li>
      <li><img src="/static/img/news.png" alt="">特跑族组委会向尚善公益特跑族组委会向尚善公益</li>
      <li><img src="/static/img/news.png" alt="">三天走出一个马拉松</li>
      <li><img src="/static/img/news.png" alt="">特跑族组委会向尚善公益特跑族组委会向尚善公益</li>
      <li><img src="/static/img/news.png" alt="">三天走出一个马拉松</li>
      <li><img src="/static/img/news.png" alt="">特跑族组委会向尚善公益特跑族组委会向尚善公益</li>
    </ul>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">

</style>
