<template lang="html">
<div class="container newindex">
  <div class="row">
    <div class="col-xs-9 bgw">
      <span class="more">MORE + </span><h4 class="title">新闻列表 / NEWS LIST</h4>
      <hr>
    </div>
    <div class="col-xs-3">
      <div  style="margin:0 -15px 0 0;" class="bgw">
        dddd
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-">

    </div>
  </div>
</div>
</template>

<script>
export default {
  name: 'newsIndex',
  data () {
    return {}
  }
}
</script>

<style lang="css">
.newindex{
  margin-top: 15px;
}
</style>
