<template lang="html">
  <div class="imglist clearfix bgw">
    <h4 class="title_two">相关图片 / Related pictures</h4>
    <ul>
      <li><a href="#"><img src="/static/img/ad01.png" alt=""></a></li>
      <li><a href="#"><img src="/static/img/ad02.png" alt=""></a></li>
      <li><a href="#"><img src="/static/img/ad03.png" alt=""></a></li>
      <li><a href="#"><img src="/static/img/ad01.png" alt=""></a></li>
      <li><a href="#"><img src="/static/img/ad02.png" alt=""></a></li>
      <li><a href="#"><img src="/static/img/ad03.png" alt=""></a></li>
      <li><a href="#"><img src="/static/img/ad01.png" alt=""></a></li>
      <li><a href="#"><img src="/static/img/ad02.png" alt=""></a></li>
      <li><a href="#"><img src="/static/img/ad03.png" alt=""></a></li>
    </ul>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">

</style>
