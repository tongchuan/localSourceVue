<?php
class userController extends baseController{
	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$this->load->model('user');
		$arr=array();
		$this->load->view('user/index',$arr);
	}

	public function login(){
		$this->load->model('user');
		$arr=array();
		$this->load->view('user/login',$arr);
	}

	public function loginSubmit(){
		$username=$_POST['username'];
		$password=$_POST['password'];
		$data=NULL;
		if($username=='zhang' && $password=='123'){
			$token = TOKEN::genToken($username);
			setcookie("username", $username, time()+3600);
			setcookie("password", $password, time()+3600);
			setcookie("token", $token, time()+3600);
			// setcookie("username", $username, time()+3600,'/','www.one.com');
			// setcookie("password", $password, time()+3600,'/','www.one.com');
			// setcookie("token", $token, time()+3600,'/','www.one.com');
			$curl = new CURL();
			$param = array("username"=>$username,"password"=>$password,"token"=>$token);
			// $result = $curl->initcurl("http://www.two.com:88/user/checkToken",$param,"POST");
			$result = $curl->initcurl("http://www.one.com:88/user/checkToken",$param,"POST");
			$data['curl']=json_encode($result);
			$data['code']=10000;
			$data['msg']="";
		}else{
			$data['code']=10001;
			$data['msg']="用户名密码错误";
		}
		echo json_encode($data);
		exit();
	}

	public function logout(){
		setcookie("username", "", time()-3600);
		setcookie("password", "", time()-3600);
		setcookie("token", "", time()-3600);
		$data=NULL;
		$data['code']=10000;
		$data['msg']="";
		echo json_encode($data);
		exit();
	}

	public function checkToken(){
		$data = NULL;
		$data['msg']="";
		$param = file_get_contents('php://input');
		$param = json_decode($param,true);
		if(count($_POST)!=0){
			$data['username']=$_POST['username'];
			$data['password']=$_POST['password'];
			$data['token']=$_POST['token'];
		}else if($param!=NULL){
			$data['username']=$param['username'];
			$data['password']=$param['password'];
			$data['token']=$param['token'];
		}

		$token = TOKEN::checkToken($data['token']);
		$result=NULL;
		if($token==$data['username'].$data['password']){
			setcookie("username", $data['username'], time()+3600,'/','www.one.com:88');
			setcookie("password", $data['password'], time()+3600,'/','www.one.com:88');
			setcookie("token", $data['token'], time()+3600,'/','www.one.com:88');
			$result["code"]=10000;
			$result['msg']="";
		}else{
			$result["code"]=10001;
			$result['msg']="认证失败";
		}
		echo json_encode($result);
		exit();
		/*
		$d = NULL;
		$d = array('username' => 'zhang','password'=> '123','token'=>'333333333');
		$curl = new CURL();
		// $r = $curl->initcurl("http://www.two.com:88/user/test",$d,"POST");
		$r = $curl->initcurl("http://www.two.com:88/user/test",$d);
		echo json_encode($r);
		exit();
		*/

		/*$username=$_POST['username'];
		$password=$_POST['password'];
		$token=$_POST['token'];
		$token = TOKEN::checkToken($token);
		$data = NULL;
		if($token==$username.$password){
			setcookie("username", $username, time()+3600);
			setcookie("password", $password, time()+3600);
			setcookie("token", $token, time()+3600);
			$data["code"]=10000;
			$data['msg']="";
		}else{
			$data["code"]=10001;
			$data['msg']="认证失败";
		}
		echo json_encode($_POST);
		exit();
		*/
	}

	public function test(){
		echo "string";
		// header("P3P: CP=CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR");
		echo json_encode($_COOKIE); 
		exit();
		/*
		$data = NULL;
		$data['msg']="";
		$param = file_get_contents('php://input');
		$param = json_decode($param,true);
		var_dump($param);
		exit();
		if(count($_POST)!=0){
			$data['username']=$_POST['username'];
			$data['password']=$_POST['password'];
			$data['token']=$_POST['token'];
		}else if($param!=NULL){
			$data['username']=$param['username'];
			$data['password']=$param['password'];
			$data['token']=$param['token'];
		}

		$token = TOKEN::checkToken($data['token']);
		if($token==$data['username'].$data['password']){
			setcookie("username", $username, time()+3600);
			setcookie("password", $password, time()+3600);
			setcookie("token", $token, time()+3600);
			$data["code"]=10000;
			$data['msg']="";
		}else{
			$data["code"]=10001;
			$data['msg']="认证失败";
		}
		echo json_encode($_POST);
		exit();
		*/
		// echo $param;
		// var_dump(json_decode($param,true)['username']);
		// echo json_encode($_FILES);
		// echo json_encode($_GET);
		// echo json_encode($_POST);
		// exit();
		// $myfile = fopen("newfile.txt", "a") or die("Unable to open file!");
		// $txt = "Mickey Mouse\n\t";
		// fwrite($myfile, $txt);
		// $txt = "Minnie Mouse\n\t";
		// fwrite($myfile, $txt);
		// fclose($myfile);
		// echo json_encode($_POST);
	}
}

?>