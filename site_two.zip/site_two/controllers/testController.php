<?php

class testController extends baseController{
	
	public function index(){
		echo '<pre>'.print_r(__METHOD__,1).'</pre>';	
		
	}


	public function peas(){
		echo '<pre>'.print_r(__METHOD__,1).'</pre>';	
		echo '<pre>'.print_r(func_get_args(),1).'</pre>';	
		
	}
	public function test($arg){
		$db = new MDB("test");
		$arg['id']=$db->getCount()+1;
		$db->insert($arg);
		
		exit();
		// var_dump($db->find());

		// var_dump();
	}
}
