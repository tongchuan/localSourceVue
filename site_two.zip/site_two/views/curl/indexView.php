<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" href="/lib/css/style.css"/>
		<title><?php echo $title;?></title>
	</head>
	<body>
		<div id="container">
			<ol>
			<?php
			foreach ($list as $key => $value) {
				echo "<li><a href=".$value['link'].">".$value['name']."</a></li>";
			}
			?>
			</ol>
		</div>
	</body>
</html>
