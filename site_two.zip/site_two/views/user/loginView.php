<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="/lib/bootstrap-3.3.7/css/bootstrap.min.css">
	<script type="text/javascript" src="/lib/js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="/lib/js/jquery.cookie.js"></script>
	<script type="text/javascript" src="/lib/bootstrap-3.3.7/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/lib/js/script.js"></script>
</head>
<body>
<div class="container">
	<form class="form-horizontal">
		<h2>登录</h2>
		<div class="form-group">
			<label for="username" class="col-sm-2 control-label">用户名</label>
			<div class="col-sm-10"><input type="text" class="form-control" id="username" value="zhang" placeholder="用户名"></div>
		</div>
		<div class="form-group">
			<label for="password" class="col-sm-2 control-label">密码</label>
			<div class="col-sm-10"><input type="password" class="form-control" id="password" value="123" placeholder="密码"></div>
		</div>
		<div class="form-group">
			<div class="col-sm-offset-2 col-sm-10">
				<button type="button" class="btn btn-default" id="submitForm">登录</button>
			</div>
		</div>
	</form>
</div>
</body>
</html>