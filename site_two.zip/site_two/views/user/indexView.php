<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="/lib/bootstrap-3.3.7/css/bootstrap.min.css">
	<script type="text/javascript" src="/lib/js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="/lib/js/jquery.cookie.js"></script>
	<script type="text/javascript" src="/lib/bootstrap-3.3.7/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/lib/js/script.js"></script>
</head>
<body>
	<div class="container">
	<?php
	if($_COOKIE["username"]!=NULL){
	?>
		欢迎您，<?php echo $_COOKIE["username"]?> <a href="javascript:void(0);" id="logout">退出</a>
	<?php
	}else{
		echo '<a href="/user/login" target="_blank">登录</a>';
	}
	?>
	<script type="text/javascript" src="http://www.one.com:88/user/index?token=<?php echo $_COOKIE["token"]?>"></script>
	<a href="http://www.one.com:88/user/index">one.com</a>
	</div>
</body>
</html>