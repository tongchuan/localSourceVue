<?php
abstract class baseModel{

}
?>
