<template lang="html">
  <div class="">

  </div>
</template>

<script>
export default {
  name: 'routertest',
  data () {
    console.log(this.$router)
    return {
      type：
    }
  }
}
</script>

<style lang="css">
</style>
