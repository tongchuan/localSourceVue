


<template lang="html">
<div class="container top2 mt bg">
  <div class="nav-title">
    <span class="title-name">测试</span>
    <span class="more">more</span>
  </div>
  <ul class="clearfix">
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
    <li><a href="#"><img src="/static/1.png" alt=""></a></li>
  </ul>
</div>
</template>

<script>
export default {
  name: 'top2',
  data () {
    return {
    }
  }
}
</script>

<style lang="css">
.nav-title{
  line-height: 35px;
  border-bottom: 1px solid #d2d2d2;
}
.title-name{
  font-size: 18px;
}
.more{
  float: right
}
.mt{
  margin-top: 15px;
}
.top2{
}
.top2 ul{
  margin-left: -10px;
  padding: 5px 0 5px;
}
.top2 ul li{
  width:12.5%;
  float: left;
  padding-left: 10px;
  margin-top: 5px;
}
.top2 ul li img{
  width: 100%;
  display: block;
  border:1px solid #d2d2d2;
}
</style>
