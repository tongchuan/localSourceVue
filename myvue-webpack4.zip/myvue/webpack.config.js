const path = require('path')
const webpack = require('webpack')
const VueLoaderPlugin = require('vue-loader/lib/plugin')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const CopyWebpackPlugin = require('copy-webpack-plugin')
const CleanWebpackPlugin = require('clean-webpack-plugin')
const ExtractTextPlugin = require("extract-text-webpack-plugin");
let isPor = false
module.exports = {
	mode: isPor ? 'production' : 'development',
	entry: {
		index: ['./src/index.jsx']
	},
	output: {
		path: path.resolve(__dirname, "dist"),
		filename: '[name]-[hash].js'
	},
	module: {
		rules: [
			{test: /\.vue$/, loader: 'vue-loader'}
		]
	},
	plugins: [
		new webpack.HotModuleReplacementPlugin(),
		new webpack.DefinePlugin({ "process.env.NODE_ENV": JSON.stringify(isPor ? 'production' : 'development') }),
		new VueLoaderPlugin(),
		new CopyWebpackPlugin([{from: 'static', to: 'dist/'}]),
		new ExtractTextPlugin({filename:'style/main.css',    			allChunks: true}),
		new CleanWebpackPlugin(['dist'],{
			root: __dirname,
			verbose: true,
			dry: false,
			allowExternal: false,
			watch: false,
			beforeEmit: false
		}),
		new HtmlWebpackPlugin({
			title: 'myvue',
			filename: 'index.html',
			template: './index.html',
			inject: 'body',
			meta: {viewport: 'width=device-width, initial-scale=1, shrink-to-fit=no'},
			minify:false,
			chunks:['index']
		}),
    require('autoprefixer')
	],
	resolve: {
		extensions: ['.js', '.jsx','.vue', '.less', '.json'],
        alias: {
            'vue': 'vue/dist/vue.js',
            '@': path.join(__dirname, 'src'),
        }
    },
    module: {
    	rules: [
    		{test:/\.vue$/,use:'vue-loader'},
			{
				test: /\.(vue|js)$/,
				exclude: /node_modules/,
				enforce: 'pre',
				include: [path.join(__dirname, 'src')],
				// use: [{
					loader: "eslint-loader",
					options: {
			            formatter: require('eslint-friendly-formatter')
			        }
				// }],
				
			},
			{
				test: /\.js$/,
				exclude: /node_modules/,
				use: [
					"babel-loader",
				],
			},
    		{test: /\.(less|css)$/,use: ExtractTextPlugin.extract({
    			fallback: 'style-loader',
    			use: ['css-loader','less-loader','postcss-loader']

    		})},
			{
				test: /\.(png|jpe?g|gif|svg)(\?.*)?$/,
				loader: 'url-loader',
				options: {
					limit: 10000,
					name: 'images/[name].[hash:7].[ext]'
				}
			},
			{
				test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/,
				loader: 'url-loader',
				options: {
					limit: 10000,
					name: 'fonts/[name].[hash:7].[ext]'
				}
			}
    		// {test: /\.css$/,use: ExtractTextPlugin.extract({
    		// 	fallback: 'style-loader',
    		// 	use: ['css-loader'],

    		// })},
    	]
    },
    devServer: {
    	contentBase: [path.join(__dirname, 'dist')],
    	compress: true,
    	port: 8089,
    	after(app){
    		// console.log(app);
    	},
    	before(){

    	},
    	allowedHosts: [],
    	clientLogLevel: 'none',
    	compress: true,
    	host: '0.0.0.0',
    	hot: true,
    	hotOnly: true,
    	https: false,
    	index: 'index.html',
    	// lazy: true,
    	noInfo: true,
    	open: true,
    	overlay: {
	      warnings: true,
	      errors: true
	    },
	    proxy: {

	    },
	    publicPath: '/',
	    useLocalIp: true,
	    // watchContentBase: true,
	    watchOptions: {
	    	poll: true
	    },
	    disableHostCheck: true 
    }
}