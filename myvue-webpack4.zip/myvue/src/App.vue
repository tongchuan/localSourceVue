<template>
  <div id="app">
    <ul>
      <li><router-link to="/">/</router-link></li>
      <li><router-link to="/foo">/foo</router-link></li>
      <li><router-link to="/bar">/bar</router-link></li>
      <router-link tag="li" to="/bar">/bar</router-link>
      <li><router-link to="/é">/é3asdaaa</router-link></li>
    </ul>
    <router-view class="view"></router-view>
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return { name: 'kaishi' }
  },
  created () {
    console.log(this)
  }
}
</script>
<style>
</style>
