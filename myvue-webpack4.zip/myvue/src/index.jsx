import Vue from 'vue'
import VueRouter from 'vue-router'
import 'es6-promise/auto'
import Vuex from 'vuex'
Vue.use(VueRouter)
Vue.use(Vuex)
import './less/base.less'
import App from './App'
import router from './router'
Vue.config.devtools = true;
Vue.config.errorHandler = function (err, vm, info) {
  console.log(['errorHandler',err, vm, info]);
}
Vue.config.warnHandler = function (msg, vm, trace) {
  console.log(['warnHandler',msg, vm, trace]);
}

let store ={}
var vue = new Vue({
	
	router,
  // store,
  // el: "#app",
	// template:``
	render: (h)=>h(App)
}).$mount('#app');

console.log(vue);